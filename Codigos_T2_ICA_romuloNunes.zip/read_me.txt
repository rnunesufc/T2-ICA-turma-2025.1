Uma vez descompactadas as pastas devem manter seus nomes originais e aestrutura de forma a permitir a leitura dos arquivos dentro das mesmas;

Os codigos de topologias contidas nas pastas T2_atividades_2a_7 necessitam dos arquivo de dados recgaces.dat recfaces_cPCA.da e recfaces_cPCABC.dat; Estes arquivos de dados podem ser gerados e modificados pelo algoritimo face_preprocessing_column.m contido na pasta T2_atividade1

Os codigos de topologias contidas nas pastas T2_Questao_8 necessitam dos arquivo de dados recgaces.dat; recfaces_cPCA.da e recfaces_cPCABCeBC_pos.dat; Estes arquivos de dados podem ser gerados e modificados pelo algoritimo face_preprocessing_column_cIntrusos.m contido na pasta T2_atividade8
