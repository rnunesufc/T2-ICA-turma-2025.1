%Rotina para obtenção dos dados de pessoas cadastradas originais (sem imagens intrusos) vetorizados de imagens 30x30
% Slavara as informações .dat do vetor de entrada e rotulos de saída para realizar o treinamento dos classificadores
%
%%permite em diferentes arquivos .dat a aplicação dos dados originais apenas vetorizados, aplicação de transformação BOXCOX e aplicação de PCA
%
%save -ascii recfaces.dat Z -> dados origiais 30x30 vetorizados
% save -ascii recfaces_cPCA.dat Z -> dados c aplicação do PCA
% save -ascii recfaces_cPCABC.dat Z -> dados c aplicação PCA e BOX COX


clear; clc; close all

pkg load image
pkg load statistics
pkg load financial

%função para implementação da trasnformada BOX COX de normalização
function x_transformed = my_boxcox(x, lambda)
  % Aplica a transformacao Box-Cox a uma matriz ou vetor.
  % Nota: Esta funcao opera em colunas (atributos).

  if lambda == 0
    x_transformed = log(x);
  else
    x_transformed = (x.^lambda - 1) ./ lambda;
  end
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fase 1 -- Carrega imagens disponiveis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
part1 = 'subject0';
part2 = 'subject';
part3 = {'.centerlight' '.glasses' '.happy' '.leftlight' '.noglasses' '.normal' '.rightlight' '.sad' '.sleepy' '.surprised' '.wink'};
part4 = strvcat(part3);

Nind=15;   % Quantidade de individuos (classes)
Nexp=length(part3);  % Quantidade de expressoes

X=[];  % Matriz que acumula imagens vetorizadas
Y=[];  % Matriz que acumula o rotulo (identificador) do individuo
Z=[];
NAME=[];
for i=1:Nind,  % Indice para os individuos
    individuo=i,
    for j=1:Nexp,   % Indice para expressoes
        if i<10,
            nome = strcat(part1,int2str(i),part4(j,:));    % Monta o nome do arquivo de imagem
        else
            nome = strcat(part2,int2str(i),part4(j,:));
        end

        Img=imread(nome);  % le imagem

        Ar = imresize(Img,[30 30]);   % (Opcional) Redimensiona imagem

        An=Ar; %An=imnoise(Ar,'gaussian',0,0.005);  % (Opcional) adiciona ruido

        A=im2double(An);  % converte (im2double) para double precision

        a=A(:);  % Etapa de vetorizacao: Empilhamento das colunas

        %ROT=zeros(Nind,1); ROT(i)=1;  % Cria rotulo da imagem (binario {0,1}, one-hot encoding)
        %ROT=strcat(part1,int2str(i));
        %ROT=-ones(Nind,1); ROT(i)=1;  % Cria rotulo da imagem (bipolar {-1,+1})
        ROT = i;   % Rotulo = indice do individuo

        X=[X a]; % Coloca cada imagem vetorizada como coluna da matriz X
        Y=[Y ROT]; % Coloca o rotulo de cada vetor como coluna da matriz Y
    end
end







Z=[X;Y];  % Formato 01 vetor de atributos por coluna: DIM(Z) = (p+1)xN
Z=Z';     % Formato 01 vetor de atributos por linha: DIM(Z) = Nx(p+1)

save -ascii recfaces.dat Z


%_______________Exibe o efeito do redimensionamento da imagem p 30x30
        Img=imread('subject01.normal');  % le imagem

        Ar = imresize(Img,[30 30]);   % (Opcional) Redimensiona imagem

        % Exiba a imagem original e a redimensionada para comparação
subplot(1, 2, 1);
imshow(Img);
title('Imagem Original');

subplot(1, 2, 2);
imshow(Ar);
title(sprintf('Imagem Redimensionada (30 x 30)'));




% Plota o histograma de todos os pixels para ver a distribuição geral antes de quisquer transformação (analise de skewness)
figure;
hist(X(:));
title('Histograma da Distribuicao dos Pixels Originais');
xlabel('Valor do Pixel');
ylabel('Frequencia');

% Calcula a assimetria para cada um dos 900 atributos e mostra a media
sk_vector = skewness(X');
media_sk_original = mean(sk_vector);
fprintf('Assimetria media dos pixels originais: %.4f\n\n', media_sk_original);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TRANSFORMAÇÃO BOX-COX AQUI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Escolha o melhor lambda para o seu teste. Usaremos 0 (log) para corrigir
% a alta assimetria dos seus dados originais, como vimos.
lambda_teste = 0;

% Chama a funcao com a matriz transposta (amostras x atributos)
[X_bc] = my_boxcox(X', lambda_teste);

% Retranspoe para o formato original (atributos x amostras)
X_bc = X_bc';


% Plota o histograma de todos os pixels para ver a distribuição geral antes do PCA (analise de skewness)
figure;
hist(X_bc(:));
title('Histograma da Distribuicao dos Pixels Originais com BOXCOX');
xlabel('Valor do Pixel');
ylabel('Frequencia');

% Calcula a assimetria para cada um dos 900 atributos e mostra a media
sk_vector = skewness(X_bc');
media_sk_original = mean(sk_vector);
fprintf('Assimetria media dos pixels originais c box cox: %.4f\n\n', media_sk_original);




##%%%%%%%% APLICACAO DE PCA (PCACOV) %%%%%%%%%%%
[V L VEi]=pcacov(cov(X')); %aplicação do PCA aos dados originais
%[V L VEi]=pcacov(cov(X_bc')); %para aplicação do PCA apos a transformação BOX COX


q=900;
Vq=V(:,1:q); Qq=Vq'; X=Qq*X;
%Vq=V(:,1:q); Qq=Vq'; X_bc=Qq*X_bc;

VEq=cumsum(VEi); figure; plot(VEq,'r-','linewidth',3);

xlabel('Autovalor');
ylabel('Variancia explicada acumulada');
q98 = find(VEq >= 98, 1, 'first')

Vq=V(:,1:q); Qq=Vq'; X=Qq*X; %sem redução de dimensionalidade
Vq=V(:,1:q98); Qq=Vq'; X=Qq*X; %c redução de dimensionalidade
%Vq=V(:,1:q98); Qq=Vq'; X_bc=Qq*X_bc;
VEq=cumsum(VEi); figure; plot(VEq,'r-','linewidth',3);
xlabel('Autovalor');
ylabel('Variancia explicada acumulada');



Z=[X;Y];  % Formato 01 vetor de atributos por coluna: DIM(Z) = (p+1)xN
%Z=[X_bc;Y];
Z=Z';     % Formato 01 vetor de atributos por linha: DIM(Z) = Nx(p+1)

save -ascii recfaces_cPCA.dat Z


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Análise da Distribuição dos Dados Originais p transformada BOXCOX
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('--- Analise dos Dados Originais ---\n');


% Plota o histograma de todos os pixels para ver a distribuição geral depois do  do PCA
figure;
hist(X(:));
title('Histograma da Distribuicao dos Pixels depois do PCA');
xlabel('Valor do Pixel');
ylabel('Frequencia');

% Calcula a assimetria para cada um dos 900 atributos e mostra a media
sk_vector = skewness(X');
media_sk_original = mean(sk_vector);
fprintf('Assimetria media dos pixels originais apos PCA: %.4f\n\n', media_sk_original);


lambda_teste = 1;

% Chama a funcao com a matriz transposta (amostras x atributos)
[X_bc] = my_boxcox(X', lambda_teste);

% Retranspoe para o formato original (atributos x amostras)
X_bc = X_bc';

% Plota o histograma de todos os pixels para ver a distribuição geral antes do PCA (analise de skewness)
figure;
hist(X_bc(:));
title('Histograma da Distribuicao dos Pixels Originais m PCA seguido BOXCOX');
xlabel('Valor do Pixel');
ylabel('Frequencia');

% Calcula a assimetria para cada um dos 900 atributos e mostra a media
sk_vector = skewness(X_bc');
media_sk_original = mean(sk_vector);
fprintf('Assimetria media dos pixels com PCA seguido BOXCOX: %.4f\n\n', media_sk_original);
Z=[X_bc;Y];
Z=Z';     % Formato 01 vetor de atributos por linha: DIM(Z) = Nx(p+1)

save -ascii recfaces_cPCABC.dat Z
