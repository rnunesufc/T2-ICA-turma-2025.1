clear; clc;

% 1. Carrega o arquivo de dados com os intrusos

Z = load('recfaces_cPCAeBC_pos.dat');

% -----------------------------------------------------------
% Parâmetros do Experimento
% -----------------------------------------------------------
Nr = 50; % Número de Rodadas do Experimento
Ptrain = 80; % Porcentagem de treinamento

% -----------------------------------------------------------
% Parâmetros Específicos do Classificador
% -----------------------------------------------------------
threshold = 0.7; % Limiar de decisão para o cenário de intruso

% -----------------------------------------------------------
% Inicializa vetores para armazenar os resultados de todas as rodadas
% -----------------------------------------------------------
acuracias_validacao = zeros(Nr, 1);
tempos_rodada = zeros(Nr, 1);
fps_rodada = zeros(Nr, 1);
fns_rodada = zeros(Nr, 1);
sensibilidade_rodada = zeros(Nr, 1);
precisao_rodada = zeros(Nr, 1);
tps_rodada = zeros(Nr, 1);
tns_rodada = zeros(Nr, 1);

% -----------------------------------------------------------
% Loop Principal de Rodadas (Treinamento e Validação)
% -----------------------------------------------------------
for rodada = 1:Nr
    fprintf('\n--- Rodada %d de %d ---\n', rodada, Nr);
    tic; % Inicia o cronômetro

    % --- Lógica de separação para o cenário de intrusos ---
    intruder_label = 16;
    validos_indices = find(Z(:, end) ~= intruder_label);
    intrusos_indices = find(Z(:, end) == intruder_label);

    % Separa os dados de indivíduos válidos
    Z_validos = Z(validos_indices, :);
    N_validos = size(Z_validos, 1);

    % Separa os intrusos
    Z_intrusos = Z(intrusos_indices, :);

    % Embaralha e separa o conjunto de indivíduos válidos
    random_indices = randperm(N_validos);
    N_treinamento_validos = floor((Ptrain/100) * N_validos);

    Z_treino = Z_validos(random_indices(1:N_treinamento_validos), :);

    % O conjunto de validação dos válidos e intrusos
    Z_validacao_validos = Z_validos(random_indices(N_treinamento_validos + 1:end), :);
    Z_validacao = [Z_validacao_validos; Z_intrusos];

    % Embaralha o conjunto de validação para misturar válidos e intrusos
    random_validacao = randperm(size(Z_validacao, 1));
    Z_validacao = Z_validacao(random_validacao, :);

    % Extrai X e Y para os conjuntos
    X_treino = Z_treino(:, 1:end-1)';
    Y_treino = Z_treino(:, end)';

    X_validacao = Z_validacao(:, 1:end-1)';
    Y_validacao = Z_validacao(:, end)';

    % -----------------------------------------------------------
    % Normalização dos Dados (Zscore)
    % -----------------------------------------------------------
    % Calcula média e desvio padrão do conjunto de TREINAMENTO
    mu = mean(X_treino, 2);
    sigma = std(X_treino, 0, 2);

    % Aplica a normalização Zscore
    X_treino_norm = (X_treino - mu) ./ sigma;
    X_validacao_norm = (X_validacao - mu) ./ sigma;

    % -----------------------------------------------------------
    % Treinamento do Classificador MQ
    % -----------------------------------------------------------
    num_classes = length(unique(Y_treino));

    % Criação da matriz de saídas desejadas (target) para o one-hot encoding
    D_treino = zeros(num_classes, size(Y_treino, 2));
    for c = 1:num_classes
        D_treino(c, Y_treino == c) = 1;
    end

    % Treinamento (cálculo da matriz de pesos W)
    W = (X_treino_norm * X_treino_norm') \ X_treino_norm * D_treino';

    % -----------------------------------------------------------
    % Validação do Classificador
    % -----------------------------------------------------------
    % Classificação do conjunto de validação
    Y_predito_validacao = W' * X_validacao_norm;

    % Determinação da classe prevista e do score máximo
    [max_probs, Y_previsto_validacao] = max(Y_predito_validacao, [], 1);

    % -----------------------------------------------------------
    % Cálculo das Métricas de Segurança
    % -----------------------------------------------------------
    TP = 0; % True Positives (Válido -> Válido)
    FP = 0; % False Positives (Intruso -> Válido)
    TN = 0; % True Negatives (Intruso -> Intruso)
    FN = 0; % False Negatives (Válido -> Intruso)

    for i = 1:length(Y_validacao)
        % Válidos
        if Y_validacao(i) ~= intruder_label
            if max_probs(i) >= threshold && Y_previsto_validacao(i) == Y_validacao(i)
                TP = TP + 1;
            else
                FN = FN + 1;
            end
        % Intrusos
        else
            if max_probs(i) < threshold
                TN = TN + 1;
            else
                FP = FP + 1;
            end
        end
    end

    total_validacao = length(Y_validacao);

    % Armazenamento das métricas
    acuracias_validacao(rodada) = (TP + TN) / total_validacao * 100;

    % Cálculos de taxas e médias
    taxa_falso_positivo_rodada = (FP / (FP + TN)) * 100;
    taxa_falso_negativo_rodada = (FN / (FN + TP)) * 100;
    sensibilidade_rodada(rodada) = (TP / (TP + FN)) * 100;
    precisao_rodada(rodada) = (TP / (TP + FP)) * 100;
    tps_rodada(rodada) = TP;
    tns_rodada(rodada) = TN;
    fps_rodada(rodada) = FP;
    fns_rodada(rodada) = FN;

    % --- Para o cronômetro ---
    tempos_rodada(rodada) = toc;

    fprintf('Acurácia Validação: %.2f%% | Tempo da Rodada: %.2f segundos\n', acuracias_validacao(rodada), tempos_rodada(rodada));
end

% -----------------------------------------------------------
% Cálculo e Exibição das Estatísticas Finais
% -----------------------------------------------------------
fprintf('\n--- Estatísticas Finais de Acurácia (em %%): ---\n');
fprintf('\nConjunto de Validação:\n');
fprintf('  Média:        %.2f\n', mean(acuracias_validacao));
fprintf('  Desvio Padrão: %.2f\n', std(acuracias_validacao));
fprintf('  Mediana:      %.2f\n', median(acuracias_validacao));
fprintf('  Mínimo:       %.2f\n', min(acuracias_validacao));
fprintf('  Máximo:       %.2f\n', max(acuracias_validacao));

fprintf('\n--- Estatísticas de Tempo de Execução (em segundos): ---\n');
fprintf('  Média:        %.2f\n', mean(tempos_rodada));
fprintf('  Mínimo:       %.2f\n', min(tempos_rodada));
fprintf('  Máximo:       %.2f\n', max(tempos_rodada));

fprintf('\n--- Estatísticas Finais de Métricas de Segurança (Média por Rodada): ---\n');
fprintf('\nTP (Média): %.2f\n', mean(tps_rodada));
fprintf('TN (Média): %.2f\n', mean(tns_rodada));
fprintf('FP (Média): %.2f\n', mean(fps_rodada));
fprintf('FN (Média): %.2f\n', mean(fns_rodada));
fprintf('\nTaxa Falso Positivo (Média): %.2f%%\n', mean(fps_rodada));
fprintf('Taxa Falso Negativo (Média): %.2f%%\n', mean(fns_rodada));
fprintf('Sensibilidade (Média): %.2f%%\n', mean(sensibilidade_rodada));
fprintf('Precisão (Média): %.2f%%\n', mean(precisao_rodada));
