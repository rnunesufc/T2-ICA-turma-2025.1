% Routines for opening face images and convert them to column vectors
% by stacking the columns of the face matrix one beneath the other.
%
% Last modification: 10/08/2021
% Author: Guilherme Barreto

clear; clc; close all

pkg load image
pkg load statistics
pkg load financial

% Funcao Box-Cox
function x_transformed = my_boxcox(x, lambda)
  epsilon = 1e-6;
  if lambda == 0
    x_transformed = log(x + epsilon);
  else
    x_transformed = (x.^lambda - 1) ./ lambda;
  end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Carrega dados dos 15 individuos cadastrados
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
part1 = 'subject0'; part2 = 'subject';
part3 = {'.centerlight' '.glasses' '.happy' '.leftlight' '.noglasses' '.normal' '.rightlight' '.sad' '.sleepy' '.surprised' '.wink'};
part4 = strvcat(part3);
Nind=15; Nexp=length(part3);
X_cadastrados=[]; Y_cadastrados=[];

for i=1:Nind,
    for j=1:Nexp,
        if i<10, nome = strcat(part1,int2str(i),part4(j,:));
        else nome = strcat(part2,int2str(i),part4(j,:)); end
        Img=imread(nome);
        Ar = imresize(Img,[30 30]);
        A=im2double(Ar); a=A(:); ROT = i;
        X_cadastrados=[X_cadastrados a]; Y_cadastrados=[Y_cadastrados ROT];
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Carrega dados dos 11 intrusos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N_intrusos = 11;
X_intrusos=[]; Y_intrusos=[];

for i=1:N_intrusos,
    if i < 10, nome = sprintf('INTRUSO_0%d.jpg', i);
    else nome = sprintf('INTRUSO_%d.jpg', i); end
    Img=imread(nome);
    if (size(Img, 3) > 1), Img = rgb2gray(Img); end
    Ar = imresize(Img,[30 30]); A=im2double(Ar); a=A(:);
    ROT = 16;
    X_intrusos=[X_intrusos a]; Y_intrusos=[Y_intrusos ROT];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PIPELINE 1: Dados Originais (apenas cadastrados)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Executando Pipeline 1 - Dados Originais vetorizados...\n');
Z = [X_cadastrados; Y_cadastrados];
Z = Z';
save -ascii recfaces.dat Z;
fprintf('Pipeline 1 concluido. Arquivo salvo: recfaces.dat \n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PIPELINE 2: PCA (apenas cadastrados)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Executando Pipeline 2 - Dados Originais com PCA 98  \n');
% Aplica PCA
[V L VEi]=pcacov(cov(X_cadastrados'));
q98 = find(cumsum(VEi) >= 98, 1, 'first');
Vq=V(:,1:q98); Qq=Vq'; X_pca_cadastrados = Qq*X_cadastrados;
% Salva o arquivo de dados
Z = [X_pca_cadastrados; Y_cadastrados];
Z = Z';
save -ascii recfaces_cPCA.dat Z;
fprintf('Pipeline 2 concluido. Arquivo salvo: recfaces_cPCA.dat \n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PIPELINE 3: Box-Cox + PCA (apenas cadastrados)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Executando Pipeline 3 - Dados Originais c PCA e BOXCOX \n');
% Aplica Box-Cox (lambda=0)
X_bc = my_boxcox(X_cadastrados', 0);
X_bc = X_bc';
% Aplica PCA
[V L VEi]=pcacov(cov(X_bc'));
q98 = find(cumsum(VEi) >= 98, 1, 'first');
Vq=V(:,1:q98); Qq=Vq'; X_bc_pca_cadastrados = Qq*X_bc;
% Salva o arquivo de dados
Z = [X_bc_pca_cadastrados; Y_cadastrados];
Z = Z';
save -ascii recfaces_cPCAeBC.dat Z;
fprintf('Pipeline 3 concluido. Arquivo salvo: recfaces_cPCAeBC.dat \n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PIPELINE 4: Box-Cox + PCA (cadastrados + intrusos)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Executando Pipeline - Dados Originais e Intrusos c PCA e BOXCOX  4\n');
% Combina os dados
X_completo = [X_cadastrados, X_intrusos];
Y_completo = [Y_cadastrados, Y_intrusos];
% Aplica Box-Cox (lambda=0)
X_bc = my_boxcox(X_completo', 0);
X_bc = X_bc';
% Aplica PCA
[V L VEi]=pcacov(cov(X_bc'));
q98 = find(cumsum(VEi) >= 98, 1, 'first');
Vq=V(:,1:q98); Qq=Vq'; X_completo_bc_pca = Qq*X_bc;
% Salva o arquivo de dados
Z = [X_completo_bc_pca; Y_completo];
Z = Z';
save -ascii recfaces_cPCAeBC_pos.dat Z;
fprintf('Pipeline 4 concluido. Arquivo salvo: recfaces_cintrusos.dat\n');

fprintf('\nTodos os pipelines foram executados. Agora voce pode carregar e testar cada arquivo de dados individualmente.\n');
