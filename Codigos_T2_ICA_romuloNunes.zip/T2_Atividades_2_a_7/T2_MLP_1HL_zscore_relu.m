clear; clc;

% 1. Carrega o arquivo de dados (agora contendo APENAS indivíduos cadastrados)
Z = load('recfaces_cPCA.dat');


% -----------------------------------------------------------
% Declaração das Funções Locais de ativação e sua derivada
% -----------------------------------------------------------

function a = activation(z, func_name)
    if nargin < 2
        func_name = 'sigmoid';
    end
    if strcmp(func_name, 'sigmoid')
        a = 1.0 ./ (1.0 + exp(-z));
    elseif strcmp(func_name, 'tanh')
        a = tanh(z);
    elseif strcmp(func_name, 'relu')
        a = max(0, z);
    elseif strcmp(func_name, 'leaky_relu')
        a = max(0.01 * z, z);
    elseif strcmp(func_name, 'linear')
        a = z;
    else
        error('Função de ativação não suportada.');
    end
end


function da = activation_derivative(a, func_name)
    if nargin < 2
        func_name = 'sigmoid'; % Valor padrão
    end
    if strcmp(func_name, 'sigmoid')
        da = a .* (1 - a);
    elseif strcmp(func_name, 'tanh')
        da = 1 - a.^2;
    elseif strcmp(func_name, 'relu')
        da = (a > 0); % Retorna 1 se a > 0, 0 caso contrário
    elseif strcmp(func_name, 'leaky_relu')
        da = ones(size(a));
        da(a <= 0) = 0.01;
    elseif strcmp(func_name, 'linear')
        da = ones(size(a));
    else
        error('Derivada da função de ativação não suportada.');
    end
end

% -----------------------------------------------------------
% Funções de normalização dos dados
% -----------------------------------------------------------


function normalized_data = normalizeData(data, method, new_min, new_max)
    if nargin < 2
        error('Método de normalização não especificado.');
    end
    if strcmp(method, 'z-score')
        mu = mean(data);
        sigma = std(data);
        sigma(sigma == 0) = 1;
        normalized_data = (data - mu) ./ sigma;
    elseif strcmp(method, 'min-max')
        if nargin < 4
            new_min = 0;
            new_max = 1;
        end
        data_min = min(data);
        data_max = max(data);
        range = data_max - data_min;
        range(range == 0) = 1;
        normalized_data = (data - data_min) ./ range * (new_max - new_min) + new_min;
    elseif strcmp(method, 'min-max-neg1-1') % Nova opção para normalização entre -1 e 1
        data_min = min(data);
        data_max = max(data);
        range = data_max - data_min;
        range(range == 0) = 1; % Evita divisão por zero

        novo_min = -1;
        novo_max = 1;

        normalized_data = (data - data_min) ./ range * (novo_max - novo_min) + novo_min;
    else
        error('Método de normalização não suportado. Use "z-score", "min-max" ou "min-max-neg1-1".');
    end
end
% -----------------------------------------------------------
% Parâmetros do Experimento
% -----------------------------------------------------------
Nr = 10; % Número de Rodadas do Experimento
Ptrain = 80; % Porcentagem de treinamento

% Inicializa vetores para armazenar os resultados de todas as rodadas
acuracias_treino = zeros(Nr, 1);
acuracias_validacao = zeros(Nr, 1);
tempos_rodada = zeros(Nr, 1);


% -----------------------------------------------------------
% Loop Principal de Rodadas (Treinamento e Validação)
% -----------------------------------------------------------
for rodada = 1:Nr
    fprintf('\n--- Rodada %d de %d ---\n', rodada, Nr);

    % --- Lógica de separação simplificada (sem intrusos) ---
    [N_total, ~] = size(Z);
    N_treinamento = floor((Ptrain/100) * N_total);

    % Embaralha todo o conjunto de dados
    random_indices = randperm(N_total);
    Z_shuffled = Z(random_indices, :);

    % Separa os conjuntos de treino e validação
    Z_treino = Z_shuffled(1:N_treinamento, :);
    Z_validacao = Z_shuffled(N_treinamento + 1:end, :);

    % Extrai X e Y para os conjuntos
    X_treino = Z_treino(:, 1:end-1);
    Y_treino = Z_treino(:, end);
    X_validacao = Z_validacao(:, 1:end-1);
    Y_validacao = Z_validacao(:, end);


      % --- Normalização dos dados de treino e validação (Min-Max para [-1, 1]) ---
%X_treino_normalizado = normalizeData(X_treino, 'min-max-neg1-1');
%X_validacao_normalizado = normalizeData(X_validacao, 'min-max-neg1-1');




    % --- Normalização dos dados de treino e validação (Z-Score) ---
    % 1. Calcule a média e o desvio padrão APENAS nos dados de TREINO
    mu = mean(X_treino);
    sigma = std(X_treino);

    % 2. Normalize o conjunto de TREINO usando seus próprios parâmetros
    X_treino_normalizado = normalizeData(X_treino, 'z-score');

    % 3. Normalize o conjunto de VALIDAÇÃO USANDO OS PARÂMETROS DO TREINO
    X_validacao_normalizado = (X_validacao - mu) ./ sigma;

    % -----------------------------------------------------------
    % TREINAMENTO DA MLP COM UMA CAMADA ESCONDIDA E BACKPROPAGATION
    % -----------------------------------------------------------
    tic;

    % Parâmetros do Treinamento
    alpha = 0.05;
    num_iteracoes = 8000;
    num_hidden_units = 50;
    Nclasses = 15;
    Nsamples_treino = size(Y_treino, 1);
    Nfeatures = size(X_treino, 2);

    % Inicializa pesos e bias aleatoriamente
    W1 = randn(Nfeatures, num_hidden_units) * 0.01;
    b1 = zeros(1, num_hidden_units);
    W2 = randn(num_hidden_units, Nclasses) * 0.01;
    b2 = zeros(1, Nclasses);

    T = zeros(Nsamples_treino, Nclasses);
    for i = 1:Nsamples_treino
        T(i, Y_treino(i)) = 1;
    end

    for iter = 1:num_iteracoes
        % --- Propagação para a Frente (Forward Propagation) ---
        z1 = X_treino_normalizado * W1 + repmat(b1, Nsamples_treino, 1);
        a1 = activation(z1, 'relu'); % Usando ReLU para a camada escondida

        z2 = a1 * W2 + repmat(b2, Nsamples_treino, 1);
        h = activation(z2, 'sigmoid'); % Usando Sigmoid para a saída

        % --- Retropropagação do Erro (Backpropagation) ---
        delta2 = h - T;
        derivada_a1 = activation_derivative(a1, 'relu');
        delta1 = (delta2 * W2') .* derivada_a1;

        % --- Cálculo dos Gradientes ---
        dW2 = a1' * delta2 / Nsamples_treino;
        db2 = sum(delta2, 1) / Nsamples_treino;
        dW1 = X_treino_normalizado' * delta1 / Nsamples_treino;
        db1 = sum(delta1, 1) / Nsamples_treino;

        % --- Atualização dos Pesos e Bias ---
        W1 = W1 - alpha * dW1;
        b1 = b1 - alpha * db1;
        W2 = W2 - alpha * dW2;
        b2 = b2 - alpha * db2;
    end

    % --- Para o cronômetro e armazena o tempo da rodada ---
    tempos_rodada(rodada) = toc;

    % -----------------------------------------------------------
    % Avaliação e Armazenamento dos Resultados da Rodada
    % -----------------------------------------------------------

    % Avaliação no conjunto de treino
    z1_treino = X_treino_normalizado * W1 + repmat(b1, Nsamples_treino, 1);
    a1_treino = activation(z1_treino, 'relu');
    z2_treino = a1_treino * W2 + repmat(b2, Nsamples_treino, 1);
    saidas_treino_brutas = activation(z2_treino, 'sigmoid');
    [~, classes_previstas_treino] = max(saidas_treino_brutas, [], 2);
    acuracias_treino(rodada) = sum(classes_previstas_treino == Y_treino) / N_treinamento * 100;

    % Avaliação no conjunto de validação
    Nsamples_validacao = size(X_validacao_normalizado, 1);
    z1_val = X_validacao_normalizado * W1 + repmat(b1, Nsamples_validacao, 1);
    a1_val = activation(z1_val, 'relu');
    z2_val = a1_val * W2 + repmat(b2, Nsamples_validacao, 1);
    saidas_validacao_brutas = activation(z2_val, 'sigmoid');
    [~, classes_previstas_validacao] = max(saidas_validacao_brutas, [], 2);
    acuracias_validacao(rodada) = sum(classes_previstas_validacao == Y_validacao) / Nsamples_validacao * 100;


    fprintf('Acurácia Treino: %.2f%% | Acurácia Validação: %.2f%%\n', acuracias_treino(rodada), acuracias_validacao(rodada));
    fprintf('Tempo da Rodada: %.2f segundos\n', tempos_rodada(rodada));
end

% -----------------------------------------------------------
% Cálculo e Exibição das Estatísticas Finais
% -----------------------------------------------------------
fprintf('\n--- Estatísticas Finais de Acurácia (em %%): ---\n');
fprintf('\nConjunto de Treino:\n');
fprintf('  Média:        %.2f\n', mean(acuracias_treino));
fprintf('  Desvio Padrão: %.2f\n', std(acuracias_treino));
fprintf('  Mediana:      %.2f\n', median(acuracias_treino));
fprintf('  Mínimo:       %.2f\n', min(acuracias_treino));
fprintf('  Máximo:       %.2f\n', max(acuracias_treino));

fprintf('\nConjunto de Validação:\n');
fprintf('  Média:        %.2f\n', mean(acuracias_validacao));
fprintf('  Desvio Padrão: %.2f\n', std(acuracias_validacao));
fprintf('  Mediana:      %.2f\n', median(acuracias_validacao));
fprintf('  Mínimo:       %.2f\n', min(acuracias_validacao));
fprintf('  Máximo:       %.2f\n', max(acuracias_validacao));

fprintf('\n--- Estatísticas de Tempo de Execução (em segundos): ---\n');
fprintf('  Média:        %.2f\n', mean(tempos_rodada));
fprintf('  Mínimo:       %.2f\n', min(tempos_rodada));
fprintf('  Máximo:       %.2f\n', max(tempos_rodada));







