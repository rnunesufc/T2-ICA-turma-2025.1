clear; clc;

% Carrega o arquivo de dados (agora contendo APENAS indivíduos cadastrados)
Z = load('recfaces_cPCABC.dat');


% -----------------------------------------------------------
% Parâmetros do Experimento
% -----------------------------------------------------------
Nr = 50; % Número de Rodadas do Experimento
Ptrain = 80; % Porcentagem de treinamento

% Inicializa vetores para armazenar os resultados de todas as rodadas
acuracias_treino = zeros(Nr, 1);
acuracias_validacao = zeros(Nr, 1);
tempos_rodada = zeros(Nr, 1);


% -----------------------------------------------------------
% Loop Principal de Rodadas (Treinamento e Validação)
% -----------------------------------------------------------
for rodada = 1:Nr
    fprintf('\n--- Rodada %d de %d ---\n', rodada, Nr);

    % --- Lógica de separação simplificada (sem intrusos) ---
    [N_total, ~] = size(Z);
    N_treinamento = floor((Ptrain/100) * N_total);

    % Embaralha todo o conjunto de dados
    random_indices = randperm(N_total);
    Z_shuffled = Z(random_indices, :);

    % Separa os conjuntos de treino e validação
    Z_treino = Z_shuffled(1:N_treinamento, :);
    Z_validacao = Z_shuffled(N_treinamento + 1:end, :);

    % Extrai X e Y para os conjuntos
    X_treino = Z_treino(:, 1:end-1);
    Y_treino = Z_treino(:, end);
    X_validacao = Z_validacao(:, 1:end-1);
    Y_validacao = Z_validacao(:, end);

    % Normalização dos dados de treino e validação (Z-Score)
    mu = mean(X_treino);
    sigma = std(X_treino);
    sigma(sigma == 0) = 1;
    X_treino_normalizado = (X_treino - mu) ./ sigma;
    X_validacao_normalizado = (X_validacao - mu) ./ sigma;

    % Adiciona a coluna de bias (ou intercepto)
    X_treino_bias = [ones(size(X_treino_normalizado, 1), 1), X_treino_normalizado];
    X_validacao_bias = [ones(size(X_validacao_normalizado, 1), 1), X_validacao_normalizado];

    % Transpõe os dados para o formato features x samples (se for a convenção usada)
    X_treino_transposed = X_treino_bias';
    X_validacao_transposed = X_validacao_bias';

    % Converte o vetor de rótulos Y_labels em uma matriz one-hot T
    Nclasses = 15;
    Nsamples_treino = length(Y_treino);
    T = zeros(Nclasses, Nsamples_treino);
    for i = 1:Nsamples_treino
        class_index = Y_treino(i);
        T(class_index, i) = 1;
    end

    % --- Inicia o cronômetro para medir o tempo do algoritmo ---
    tic;

    % -----------------------------------------------------------
    % TREINAMENTO E AVALIAÇÃO
    % -----------------------------------------------------------

    % Calcula a matriz de pesos W (Treinamento do Mínimos Quadrados)
    W = T * pinv(X_treino_transposed);

    % Avaliação no conjunto de treino
    saidas_treino_brutas = W * X_treino_transposed;
    [~, classes_previstas_treino] = max(saidas_treino_brutas, [], 1);
    acuracias_treino(rodada) = sum(classes_previstas_treino' == Y_treino) / Nsamples_treino * 100;

    % Avaliação no conjunto de validação
    saidas_validacao_brutas = W * X_validacao_transposed;
    [~, classes_previstas_validacao] = max(saidas_validacao_brutas, [], 1);
    acuracias_validacao(rodada) = sum(classes_previstas_validacao' == Y_validacao) / length(Y_validacao) * 100;

    % --- Para o cronômetro ---
    tempos_rodada(rodada) = toc;

    fprintf('Acurácia Treino: %.2f%% | Acurácia Validação: %.2f%%\n', acuracias_treino(rodada), acuracias_validacao(rodada));
    fprintf('Tempo da Rodada: %.2f segundos\n', tempos_rodada(rodada));
end

% -----------------------------------------------------------
% Cálculo e Exibição das Estatísticas Finais
% -----------------------------------------------------------
fprintf('\n--- Estatísticas Finais de Acurácia (em %%): ---\n');
fprintf('\nConjunto de Treino:\n');
fprintf('  Média:        %.2f\n', mean(acuracias_treino));
fprintf('  Desvio Padrão: %.2f\n', std(acuracias_treino));
fprintf('  Mediana:      %.2f\n', median(acuracias_treino));
fprintf('  Mínimo:       %.2f\n', min(acuracias_treino));
fprintf('  Máximo:       %.2f\n', max(acuracias_treino));

fprintf('\nConjunto de Validação:\n');
fprintf('  Média:        %.2f\n', mean(acuracias_validacao));
fprintf('  Desvio Padrão: %.2f\n', std(acuracias_validacao));
fprintf('  Mediana:      %.2f\n', median(acuracias_validacao));
fprintf('  Mínimo:       %.2f\n', min(acuracias_validacao));
fprintf('  Máximo:       %.2f\n', max(acuracias_validacao));

fprintf('\n--- Estatísticas de Tempo de Execução (em segundos): ---\n');
fprintf('  Média:        %.2f\n', mean(tempos_rodada));
fprintf('  Mínimo:       %.2f\n', min(tempos_rodada));
fprintf('  Máximo:       %.2f\n', max(tempos_rodada));
