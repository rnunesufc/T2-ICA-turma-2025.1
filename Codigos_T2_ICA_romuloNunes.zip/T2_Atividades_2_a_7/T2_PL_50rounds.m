clear; clc;

Z=load('recfaces.dat');


% -----------------------------------------------------------
% Declaração das Funções Locais de ativação e sua derivada
% -----------------------------------------------------------

function a = activation(z, func_name)
    if nargin < 2
        func_name = 'sigmoid';
    end

    if strcmp(func_name, 'sigmoid')
        a = 1.0 ./ (1.0 + exp(-z));
    elseif strcmp(func_name, 'tanh')
        a = tanh(z);
    elseif strcmp(func_name, 'relu')
        a = max(0, z);
    elseif strcmp(func_name, 'leaky_relu')
        a = max(0.01 * z, z);
    elseif strcmp(func_name, 'linear')
        a = z;
    else
        error('Função de ativação não suportada.');
    end
end


function da = activation_derivative(a, func_name)
    if nargin < 2
        func_name = 'sigmoid'; % Valor padrão
    end

    if strcmp(func_name, 'sigmoid')
        da = a .* (1 - a);
    elseif strcmp(func_name, 'tanh')
        da = 1 - a.^2;
    elseif strcmp(func_name, 'relu')
        da = (a > 0); % Retorna 1 se a > 0, 0 caso contrário
    elseif strcmp(func_name, 'leaky_relu')
        da = ones(size(a));
        da(a <= 0) = 0.01;
    elseif strcmp(func_name, 'linear')
        da = ones(size(a));
    else
        error('Derivada da função de ativação não suportada.');
    end
end

#OBS: Nota sobre a entrada a: Para sigmoid e tanh, é mais eficiente passar a saída da função de ativação (a) em vez da entrada (z) ]
#para o cálculo da derivada. Para relu, leaky_relu e linear, o resultado é mais simples de ser calculado a partir de a ou de uma matriz de 1's.

#__________________________________________________________________________________________________________________________________________________________

#funções de normalização dos dados

function normalized_data = normalizeData(data, method, new_min, new_max)

    if nargin < 2
        error('Método de normalização não especificado.');
    end

    if strcmp(method, 'z-score')
        % Normalização Z-Score: (x - média) / desvio padrão
        mu = mean(data);
        sigma = std(data);

        % Previne divisão por zero se o desvio padrão for zero
        sigma(sigma == 0) = 1;

        normalized_data = (data - mu) ./ sigma;

    elseif strcmp(method, 'min-max')
        % Normalização por mudança de escala
        if nargin < 4
            new_min = 0;
            new_max = 1;
        end

        data_min = min(data);
        data_max = max(data);

        % Previne divisão por zero se o max e min forem iguais
        range = data_max - data_min;
        range(range == 0) = 1;

        normalized_data = (data - data_min) ./ range * (new_max - new_min) + new_min;

    else
        error('Método de normalização não suportado. Use "z-score" ou "min-max".');
    end
end
#OBS: A normalização deve ser feita de forma separada para os conjuntos de treino e validação,
#mas usando os parâmetros (média e desvio padrão para Z-score, ou mínimo e máximo para Min-Max) calculados
#apenas com os dados de treino. Isso evita que o modelo "vaze" informações do conjunto de validação durante o treinamento.
#OBS2: Atenção: É crucial adicionar a coluna de bias depois da normalização, caso contrário, a normalização
#pode alterar o valor da coluna de 1's.

#_________________________________________________________________________________________________________________________________

% -----------------------------------------------------------
% Parâmetros do Experimento
% -----------------------------------------------------------
Nr = 50; % Número de Rodadas do Experimento
Ptrain = 80; % Porcentagem de treinamento

% Inicializa vetores para armazenar os resultados de todas as rodadas
acuracias_treino = zeros(Nr, 1);
acuracias_validacao = zeros(Nr, 1);

% Assume que Z está no formato N x (p+1)
[N_total, ~] = size(Z);
prop_treinamento = Ptrain / 100;
N_treinamento = floor(prop_treinamento * N_total);
N_validacao = N_total - N_treinamento;

% -----------------------------------------------------------
% Loop Principal de Rodadas (Treinamento e Validação)
% -----------------------------------------------------------
for rodada = 1:Nr
    fprintf('\n--- Rodada %d de %d ---\n', rodada, Nr);

    % --- Movido para dentro do Loop ---
    % 1. Embaralha e separa os dados para a rodada atual
    random_indices = randperm(N_total);
    Z_shuffled = Z(random_indices, :);
    Z_treino = Z_shuffled(1:N_treinamento, :);
    Z_validacao = Z_shuffled(N_treinamento + 1:end, :);
    X_treino = Z_treino(:, 1:end-1);
    Y_treino = Z_treino(:, end);
    X_validacao = Z_validacao(:, 1:end-1);
    Y_validacao = Z_validacao(:, end);

    % 2. Adiciona a coluna de bias (sem normalização neste teste)
    X_treino_bias = [ones(size(X_treino, 1), 1), X_treino];
    X_validacao_bias = [ones(size(X_validacao, 1), 1), X_validacao];

    % 3. Treinamento do Perceptron Logístico com MSE
    alpha = 0.1;
    num_iteracoes = 800; % Aumentado para um valor mais adequado
    Nclasses = 15;
    Nsamples_treino = size(Y_treino, 1);
    Nfeatures = size(X_treino, 2);
    all_weights_mse = zeros(Nfeatures + 1, Nclasses);

    for k = 1:Nclasses
        W_k = zeros(Nfeatures + 1, 1);
        y_k = (Y_treino == k);
        for iter = 1:num_iteracoes
            z = X_treino_bias * W_k;
            h_k = activation(z, 'sigmoid');
            derivada = activation_derivative(h_k, 'sigmoid');
            gradiente = (1/Nsamples_treino) * X_treino_bias' * ((h_k - y_k) .* derivada);
            W_k = W_k - alpha * gradiente;
        end
        all_weights_mse(:, k) = W_k;
    end

    % 4. Avaliação e Armazenamento dos Resultados da Rodada
    % Acurácia de Treino
    saidas_treino = X_treino_bias * all_weights_mse;
    [~, classes_previstas_treino] = max(saidas_treino, [], 2);
    acuracias_treino(rodada) = sum(classes_previstas_treino == Y_treino) / N_treinamento * 100;

    % Acurácia de Validação
    saidas_validacao = X_validacao_bias * all_weights_mse;
    [~, classes_previstas_validacao] = max(saidas_validacao, [], 2);
    acuracias_validacao(rodada) = sum(classes_previstas_validacao == Y_validacao) / N_validacao * 100;

    fprintf('Acurácia Treino: %.2f%% | Acurácia Validação: %.2f%%\n', acuracias_treino(rodada), acuracias_validacao(rodada));
end
#_________________________________________________________________________________________________________________________________

% -----------------------------------------------------------
% AVALIAÇÃO DO MODELO NO CONJUNTO DE TREINO
% -----------------------------------------------------------

% 1. Calcula a saída para o conjunto de treino usando os pesos treinados
saidas_treino_brutas = X_treino_bias * all_weights_mse;

% 2. Para cada amostra, a classe prevista é a que tem a maior saída
[~, classes_previstas_treino] = max(saidas_treino_brutas, [], 2);

% 3. Compara as previsões com os rótulos reais de treino
acertos_treino = sum(classes_previstas_treino == Y_treino);
acuracia_treino = acertos_treino / size(Y_treino, 1) * 100;

% -----------------------------------------------------------
% AVALIAÇÃO DO MODELO NO CONJUNTO DE VALIDAÇÃO
% -----------------------------------------------------------

% 1. Calcula a saída para o conjunto de validação
saidas_validacao_brutas = X_validacao_bias * all_weights_mse;

% 2. Para cada amostra, a classe prevista é a que tem a maior saída
[~, classes_previstas_validacao] = max(saidas_validacao_brutas, [], 2);

% 3. Compara as previsões com os rótulos reais de validação
acertos_validacao = sum(classes_previstas_validacao == Y_validacao);
acuracia_validacao = acertos_validacao / size(Y_validacao, 1) * 100;

% Exibe os resultados
fprintf('\n--- Perceptron Logístico (MSE) ---\n');
fprintf('Acurácia de Treino:    %.2f%%\n', acuracia_treino);
fprintf('Acurácia de Validação: %.2f%%\n', acuracia_validacao);


% -----------------------------------------------------------
% Cálculo e Exibição das Estatísticas Finais
% -----------------------------------------------------------
fprintf('\n--- Estatísticas Finais de Acurácia (em %%): ---\n');
fprintf('\nConjunto de Treino:\n');
fprintf('  Média:        %.2f\n', mean(acuracias_treino));
fprintf('  Desvio Padrão: %.2f\n', std(acuracias_treino));
fprintf('  Mediana:      %.2f\n', median(acuracias_treino));
fprintf('  Mínimo:       %.2f\n', min(acuracias_treino));
fprintf('  Máximo:       %.2f\n', max(acuracias_treino));

fprintf('\nConjunto de Validação:\n');
fprintf('  Média:        %.2f\n', mean(acuracias_validacao));
fprintf('  Desvio Padrão: %.2f\n', std(acuracias_validacao));
fprintf('  Mediana:      %.2f\n', median(acuracias_validacao));
fprintf('  Mínimo:       %.2f\n', min(acuracias_validacao));
fprintf('  Máximo:       %.2f\n', max(acuracias_validacao));


